export const USER_API_END_POINT="https://blurbb.onrender.com/api/v1/user";
export const POST_API_END_POINT="https://blurbb.onrender.com/api/v1/post";
export const NOTIFICATION_API_END_POINT="https://blurbb.onrender.com/api/v1/notification";
// https://blurbb.onrender.com
// https://blurbb.onrender.com